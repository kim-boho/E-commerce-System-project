/**
 * @author Sanyam Panchal
 *
 */
import { useEffect, useState } from "react";
import { Product } from "./api";
import Filter from "./components/Filter";
import Header from "./components/Header";
import ProductCard from "./components/ProductCard";
import { useProductsData } from "./hooks/useProducts";

function Home() {
  const { data: products } = useProductsData();

  const [filter, setFilter] = useState<string>();
  const [productByFilter, setProductByFilter] = useState<
    Product[] | undefined
  >();

  const updateFilter = (e: any) => {
    setFilter(e.target.value);
  };

  useEffect(() => {
    const fetchProductByBrand = () => {
      if (filter != "--select brand--") {
        const res = products?.filter((product) => product.brand == filter);
        if (res) {
          setProductByFilter(res);
        }
      } else {
        setProductByFilter(products);
      }
    };
    fetchProductByBrand();
  }, [filter]);

  useEffect(() => {
    setProductByFilter(products);
  }, [products]);

  return (
    <>
      <Header />
      <Filter updateFilter={updateFilter} />
      <>
        <div className="bg-white">
          <hr />

          <div className="mx-auto max-w-2xl py-16 px-4 sm:py-24 sm:px-6 lg:max-w-7xl lg:px-8">
            <h2 className="sr-only">Products</h2>

            {productByFilter && (
              <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
                {productByFilter?.map((product) => (
                  <ProductCard {...product}></ProductCard>
                ))}
              </div>
            )}
          </div>
        </div>
      </>
    </>
  );
}

export default Home;
