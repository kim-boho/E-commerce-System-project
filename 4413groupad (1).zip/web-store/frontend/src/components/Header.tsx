import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useIsAdmin } from "../hooks/userRequests";

function Header() {
  // checks if user exists in local session for logging out
  const checkIsLoggedIn = () => {
    return localStorage.getItem("user") != null;
  };
  const navigate = useNavigate();

  const { data: checkIsAdmin } = useIsAdmin(localStorage.getItem("user")!);

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(checkIsLoggedIn);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  useEffect(() => {
    if (isLoggedIn && checkIsAdmin) {
      setIsAdmin(checkIsAdmin);
    }
  }, []);

  useEffect(() => {
    setIsLoggedIn(checkIsLoggedIn);
  }, [isLoggedIn]);

  // function for logging out
  const logout = () => {
    localStorage.removeItem("user");
    setIsLoggedIn(checkIsLoggedIn);
    navigate("/");
  };

  const renderLoginSignup = (
    <>
      <button className="border text-center bg-transparent text-white font-extrabold text-lg hover:text-black w-32">
        <Link to="/login">Login</Link>
      </button>
      <button className="border text-center bg-transparent text-white font-extrabold text-lg hover:text-black w-32">
        <Link to="/signup">Signup</Link>
      </button>
    </>
  );

  const renderLogoutCart = (
    <>
      {isAdmin == true && (
        <button className="border text-center bg-transparent text-white font-extrabold text-lg hover:text-black w-32">
          <Link to="/admin">Analytics</Link>
        </button>
      )}

      <button className="border text-center bg-transparent text-white font-extrabold text-lg hover:text-black w-32">
        <Link to="/cart">Cart</Link>
      </button>
      <button
        className="border text-center bg-transparent text-white font-extrabold text-lg hover:text-black w-32"
        onClick={logout}
      >
        Logout
      </button>
    </>
  );

  return (
    <div className="w-full bg-red-700 h-13 flex justify-between font-bold text-lg ">
      <div>
        <button className="bg-white w-52 my-3 ml-4 rounded-2xl text-lg">
          <Link to="/">Group AD Web Store</Link>
        </button>
      </div>

      <div className="flex">
        {isLoggedIn ? renderLogoutCart : renderLoginSignup}
      </div>
    </div>
  );
}

export default Header;
