// @author Michelangelo Granato
import axios from "axios";
import { useQuery } from "react-query";
import { User } from "../api";

export interface SignupResponse {
  email?: string;
  errorMessage?: string;
}
export interface LoginResponse {
  result?: boolean;
  errorMessage?: string;
}
// sends login request, response is either success or an error message to display on ui
export const login = async (user: User) => {
  const { data } = await axios.post<LoginResponse>(`/api/login`, user);
  return data;
};

// sends signup request, response is either user's email to store in local session
// or an error message to display on ui
export const signup = async (user: User) => {
  const { data } = await axios.post<SignupResponse>(`/api/signup/`, user);
  return data;
};

const getIsAdmin = async (email: string) => {
  const { data } = await axios.get<boolean>(`/api/users/isAdmin`, {
    params: { email: email },
  });
  return data;
};
export const useIsAdmin = (email: string) => {
  return useQuery<boolean>("isAdmin", () => getIsAdmin(email));
};
