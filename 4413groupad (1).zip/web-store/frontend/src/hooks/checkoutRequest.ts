// @author Michelangelo Granato

import axios from "axios";
import { Cart, CheckoutRequest, ShippingInfo } from "../api";

export const getUserCart = async (userEmail: string) => {
  const { data } = await axios.get<Cart[]>(`/api/cart`, {
    params: { email: userEmail },
  });
  return data;
};

export const setUserCart = async (cart: Cart[]) => {
  const { data } = await axios.post<Cart[]>(`/api/cart`, {
    cart,
  });
  return data;
};

export const postCheckout = async (checkoutRequest: CheckoutRequest) => {
  console.log(checkoutRequest.shippingInfo);
  const res = await axios.post<ShippingInfo>(
    `/api/users/address`,
    checkoutRequest.shippingInfo
  );
  if (!res.data) return null;
  else checkoutRequest.shippingInfo = res.data;

  console.log(checkoutRequest.cart);
  const cRes = await setUserCart(checkoutRequest.cart);
  if (!cRes) return null;

  const { data } = await axios.post<CheckoutRequest>(
    `/api/checkout/`,
    checkoutRequest
  );
  return data;
};
