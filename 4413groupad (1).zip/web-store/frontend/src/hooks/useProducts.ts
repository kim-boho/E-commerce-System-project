// @author Michelangelo Granato

import axios from "axios";
import { useQuery } from "react-query";
import { Cart, Product } from "../api";
import { getUserCart } from "./checkoutRequest";

const getProductsData = async () => {
  const { data } = await axios.get<Product[]>(`/api/products`);
  return data;
};

export const getProductsByListOfIds = async (email: string) => {
  const cart = await getUserCart(email);
  const productIds = cart.map((p) => p.productId);

  if (productIds.length > 0) {
    const { data } = await axios.get<CartProduct[]>(`/api/products/by-ids`, {
      params: { ids: productIds.toString() },
    });

    data.forEach((c) => (c.quantity = findCartItemQuantity(c.productId, cart)));

    return data;
  } else return null;
};

const findCartItemQuantity = (id: number, cart: Cart[]) => {
  const res = cart.find((c) => c.productId == id);
  return res != null ? res.quantity : -1;
};

export interface CartProduct extends Product {
  quantity: number;
}

const getProductById = async (productId: number) => {
  const { data } = await axios.get<Product>(`/api/products/${productId}`);
  return data;
};
export interface AddToCartResponse {
  result: boolean;
  errMsgs: string[];
}
export const postAddToCart = async (item: Cart) => {
  console.log(item);
  const { data } = await axios.post<AddToCartResponse>(`/api/cart/add`, item);
  return data;
};
export const useProductsData = () => {
  return useQuery<Product[]>("products", () => getProductsData());
};

export const useProductData = (productId: number) => {
  return useQuery<Product>("product", () => getProductById(productId));
};

export const useProductsByListOfIds = (email: string) => {
  return useQuery<CartProduct[] | null>("product", () =>
    getProductsByListOfIds(email)
  );
};
