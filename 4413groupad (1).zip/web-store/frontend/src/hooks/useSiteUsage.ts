// @author Michelangelo Granato

import axios from "axios";
import { useQuery } from "react-query";
import { VisitEvent } from "../api";

export interface UsageResponse {
  visitEvents: VisitEvent[];
}

const getSiteUsageData = async () => {
  const { data } = await axios.get<UsageResponse>(`/api/admin/website-usage`);

  return data;
};
export const postVisitEvent = async (productId: number) => {
  await axios.post<void>(`/api/admin/visitEvent`, {
    productId: productId,
    eventType: "VIEW",
  });
};
export const postCartEvent = async (productId: number) => {
  await axios.post<void>(`/api/admin/visitEvent`, {
    productId: productId,
    eventType: "CART",
  });
};
export const useSiteUsageData = () => {
  return useQuery<UsageResponse>("siteUsage", () => getSiteUsageData());
};
