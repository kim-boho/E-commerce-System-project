// @author Michelangelo Granato

import axios from "axios";
import { useQuery } from "react-query";
import { Purchase } from "../api";

export interface PurchaseDataResponse {
  purchase: Purchase[];
}

const getPurchaseData = async () => {
  const { data } = await axios.get<PurchaseDataResponse>(
    `/api/admin/monthly-purchases`
  );

  return data;
};

export const usePurchaseData = () => {
  return useQuery<PurchaseDataResponse>("purchaseData", () =>
    getPurchaseData()
  );
};
