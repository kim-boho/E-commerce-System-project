import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "./components/Header";
import { login } from "./hooks/userRequests";
interface ErrorMessage {
  name?: string;
  message?: string;
}

const Login = () => {
  const [errorMessages, setErrorMessages] = useState<ErrorMessage>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const errors = {
    email: "invalid username",
    pass: "invalid password",
    loginFail: "Invalid username or password. Please try again.",
  };

  const validate = (email: string, password: string) => {
    let result = true;
    if (email == null || email == "") {
      setErrorMessages({ name: "email", message: errors.email });
      result = false;
    }
    if (password == null || password == "") {
      setErrorMessages({ name: "pass", message: errors.pass });
      result = false;
    }
    return result;
  };

  const handleSubmit = async (event: { preventDefault: () => void }) => {
    //Prevent page reload
    event.preventDefault();

    const { email, password } = document.forms[0];
    // validate user login info
    const user = {
      email: email.value,
      password: password.value,
    };
    if (validate(user.email, user.password)) {
      const response = await login(user);
      // if login successful, save user in localstorage
      if (response.result && response.errorMessage == null) {
        setIsSubmitted(true);
        localStorage.setItem("user", user.email);
      } else {
        setErrorMessages({ name: "loginFail", message: response.errorMessage });
      }
    } else {
      setErrorMessages({ name: "loginFail", message: errors.loginFail });
    }
  };

  const renderErrorMessage = (name: string) =>
    name === errorMessages.name && (
      <div className="error">{errorMessages.message}</div>
    );

  const renderForm = (
    <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
      <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="loginFail break-words text-center text-[#cc0000]">
            {renderErrorMessage("loginFail")}
          </div>
          <div className="email-container">
            <label className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <div className="mt-1">
              <input
                name="email"
                type="email"
                autoComplete="email"
                required
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {renderErrorMessage("email")}
            </div>
          </div>
          <div className="password-container">
            <label className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <div className="mt-1">
              <input
                name="password"
                type="password"
                autoComplete="current-password"
                required
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {renderErrorMessage("password")}
            </div>
          </div>
          <div>
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Sign In
            </button>

            <h2 className="my-2 ml-44">Or</h2>

            <button
              type="button"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Link to="/signup">Create New Account</Link>
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  const renderHeader = (
    <>
      <div className="min-h-full flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <img
            className="mx-48 h-12 w-auto"
            src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg"
            alt="Workflow"
          />
          <h2 className="mt-6 mx-0 w-full text-center text-3xl font-extrabold text-gray-900">
            Sign in to your account
          </h2>
        </div>
      </div>
    </>
  );

  const renderSuccess = (
    <>
      <div className="sm:mx-auto sm:w-full sm:max-w-md min-h-full flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="text-center w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium ">
          Login Successful!
        </div>
        <button
          type="button"
          className="my-4 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Link to="/Checkout">Go To Checkout</Link>
        </button>
        <button
          type="button"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Link to="/">Back To Home</Link>
        </button>
      </div>
    </>
  );

  return (
    <div className="app">
      <Header />
      <div className="login-form">
        <div className="title">{renderHeader}</div>
        {isSubmitted ? renderSuccess : renderForm}
      </div>
    </div>
  );
};

export default Login;
