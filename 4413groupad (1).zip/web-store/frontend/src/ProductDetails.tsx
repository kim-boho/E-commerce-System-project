/**
 * @author Sanyam Panchal
 *
 */

import { Fragment, useEffect, useState } from "react";
import {
  Dialog,
  Popover,
  RadioGroup,
  Tab,
  Transition,
} from "@headlessui/react";
import { AiFillCloseCircle, AiFillStar } from "react-icons/ai";
import { useParams } from "react-router-dom";
import { postAddToCart, useProductData } from "./hooks/useProducts";
import { Product } from "./api";
import Header from "./components/Header";
import { off } from "process";
import { postCartEvent, postVisitEvent } from "./hooks/useSiteUsage";

const reviews = {
  average: 3.9,
  totalCount: 512,
  featured: [
    {
      id: 1,
      title: "Can't say enough good things",
      rating: 5,
      content: `
        <p>I was really pleased with the overall shopping experience. My order even included a little personal, handwritten note, which delighted me!</p>
        <p>The product quality is amazing, it looks and feel even better than I had anticipated. Brilliant stuff! I would gladly recommend this store to my friends. And, now that I think of it... I actually have, many times!</p>
      `,
      author: "Risako M",
      date: "May 16, 2021",
      datetime: "2021-01-06",
    },

    {
      id: 2,
      title: "Can't say enough good things",
      rating: 5,
      content: `
          <p>I was really pleased with the overall shopping experience. My order even included a little personal, handwritten note, which delighted me!</p>
          <p>The product quality is amazing, it looks and feel even better than I had anticipated. Brilliant stuff! I would gladly recommend this store to my friends. And, now that I think of it... I actually have, many times!</p>
        `,
      author: "Risako M",
      date: "May 16, 2021",
      datetime: "2021-01-06",
    },
    // More reviews...
  ],
};

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(" ");
}

export default function ProductDetails() {
  const { id } = useParams();
  const getUser = () => {
    return localStorage.getItem("user");
  };
  const productData = useProductData(Number(id)).data;
  const [open, setOpen] = useState(false);
  let [isOpen, setIsOpen] = useState(false);

  const [product, setProduct] = useState<Product | undefined>();

  useEffect(() => {
    setProduct(productData);
    if (product) postVisitEvent(product.productId);
  }, [product, productData]);

  async function setBanner(
    result: Promise<import("./hooks/useProducts").AddToCartResponse>
  ) {
    const res = await result;
    return (
      <Popover>
        res.result == true? (<p>Successfully added to cart</p>): (
        <p>Error adding to cart</p>
        {res.errMsgs?.map((e) => (
          <p>Error: {e}</p>
        ))}
        )
      </Popover>
    );
  }

  return (
    <div className="bg-white">
      {/* Mobile menu */}
      <Header />

      <main className="mt-8 max-w-2xl mx-auto pb-16 px-4 sm:pb-24 sm:px-6 lg:max-w-7xl lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:auto-rows-min lg:gap-x-8">
          <div className="lg:col-start-8 lg:col-span-5">
            <div className="flex justify-between">
              <h1 className="text-xl font-medium text-gray-900">
                {product?.name}
              </h1>
              <p className="text-xl font-medium text-gray-900">
                $ {product?.price}
              </p>
            </div>
            {/* Reviews */}
            <div className="mt-4">
              <h2 className="sr-only">Reviews</h2>
              <div className="flex items-center">
                <p className="text-sm text-gray-700">
                  {reviews.average}
                  <span className="sr-only"> out of 5 stars</span>
                </p>
                <div className="ml-1 flex items-center">
                  {[0, 1, 2, 3, 4].map((rating) => (
                    <AiFillStar
                      key={rating}
                      className={classNames(
                        reviews.average > rating
                          ? "text-yellow-400 "
                          : "text-gray-200",
                        "h-5 w-5 flex-shrink-0"
                      )}
                      aria-hidden="true"
                    />
                  ))}
                </div>
                <div aria-hidden="true" className="ml-4 text-sm text-gray-300">
                  ·
                </div>
                <div className="ml-4 flex">
                  <a
                    href="#"
                    className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                  >
                    See all {reviews.totalCount} reviews
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Image gallery */}
          <div className="mt-8 lg:mt-0 lg:col-start-1 lg:col-span-7 lg:row-start-1 lg:row-span-3">
            <h2 className="sr-only">Images</h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 lg:grid-rows-3 lg:gap-8">
              <img key={product?.productId} src={product?.imgSrc} />
            </div>
          </div>
          {/* Product details */}
          <div className="mt-12 flex flex-col ml-0 justify-end">
            <h2 className="text-sm font-medium text-gray-900">Description</h2>
            <h2 className="text-sm font-medium text-gray-900">
              {product?.description}
            </h2>
          </div>

          <div className="mt-8 lg:col-span-5">
            <button
              type="button"
              disabled={getUser() == null}
              onClick={() => {
                if (getUser() != null) {
                  const cart = {
                    email: getUser()!,
                    productId: product!.productId,
                    quantity: 1,
                  };
                  const result = postAddToCart(cart);
                  setBanner(result);
                  postCartEvent(product!.productId);
                }
              }}
              className="mt-8 w-full bg-indigo-600 border border-transparent rounded-md py-3 px-8 flex items-center justify-center text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {getUser() != null ? "Add to cart" : "Log in to add to cart"}
            </button>
          </div>
        </div>

        {/* Reviews */}
        <section aria-labelledby="reviews-heading" className="mt-16 sm:mt-24">
          <h2
            id="reviews-heading"
            className="text-lg font-medium text-gray-900"
          >
            Recent reviews
          </h2>

          <div className="mt-6 border-t border-b border-gray-200 pb-10 divide-y divide-gray-200 space-y-10">
            {reviews.featured.map((review) => (
              <div
                key={review.id}
                className="pt-10 lg:grid lg:grid-cols-12 lg:gap-x-8"
              >
                <div className="lg:col-start-5 lg:col-span-8 xl:col-start-4 xl:col-span-9 xl:grid xl:grid-cols-3 xl:gap-x-8 xl:items-start">
                  <div className="flex items-center xl:col-span-1">
                    <div className="flex items-center">
                      {[0, 1, 2, 3, 4].map((rating) => (
                        <AiFillStar
                          key={rating}
                          className={classNames(
                            review.rating > rating
                              ? "text-yellow-400"
                              : "text-gray-200",
                            "h-5 w-5 flex-shrink-0"
                          )}
                          aria-hidden="true"
                        />
                      ))}
                    </div>
                    <p className="ml-3 text-sm text-gray-700">
                      {review.rating}
                      <span className="sr-only"> out of 5 stars</span>
                    </p>
                  </div>

                  <div className="mt-4 lg:mt-6 xl:mt-0 xl:col-span-2">
                    <h3 className="text-sm font-medium text-gray-900">
                      {review.title}
                    </h3>

                    <div
                      className="mt-3 space-y-6 text-sm text-gray-500"
                      dangerouslySetInnerHTML={{ __html: review.content }}
                    />
                  </div>
                </div>

                <div className="mt-6 flex items-center text-sm lg:mt-0 lg:col-start-1 lg:col-span-4 lg:row-start-1 lg:flex-col lg:items-start xl:col-span-3">
                  <p className="font-medium text-gray-900">{review.author}</p>
                  <time
                    dateTime={review.datetime}
                    className="ml-4 border-l border-gray-200 pl-4 text-gray-500 lg:ml-0 lg:mt-2 lg:border-0 lg:pl-0"
                  >
                    {review.date}
                  </time>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center float-right mt-5">
            <button
              type="button"
              onClick={() => setIsOpen(true)}
              className="rounded-md bg-black bg-opacity-20 px-4 py-2 text-sm font-medium text-white hover:bg-opacity-30 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75"
            >
              Write a Review
            </button>
          </div>

          <Transition appear show={isOpen} as={Fragment}>
            <Dialog
              as="div"
              className="relative z-10"
              onClose={() => setIsOpen(false)}
            >
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0"
                enterTo="opacity-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100"
                leaveTo="opacity-0"
              >
                <div className="fixed inset-0 bg-black bg-opacity-25" />
              </Transition.Child>

              <div className="fixed inset-0 overflow-y-auto">
                <div className="flex min-h-full items-center justify-center p-4 text-center">
                  <Transition.Child
                    as={Fragment}
                    enter="ease-out duration-300"
                    enterFrom="opacity-0 scale-95"
                    enterTo="opacity-100 scale-100"
                    leave="ease-in duration-200"
                    leaveFrom="opacity-100 scale-100"
                    leaveTo="opacity-0 scale-95"
                  >
                    <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                      <Dialog.Title
                        as="h3"
                        className="flex justify-between text-lg font-medium leading-6 text-gray-900"
                      >
                        <h3>Write A Review </h3>
                        <button
                          className="bg-transparent hover:bg-transparent text-red-300 hover:text-red-500"
                          onClick={() => setIsOpen(false)}
                        >
                          <AiFillCloseCircle></AiFillCloseCircle>
                        </button>
                      </Dialog.Title>
                      <div className="flex flex-col mt-5">
                        <input
                          placeholder="Add a title"
                          className="border-2 border-slate-500 w-full float-left p-2 rounded-md"
                        ></input>
                        <textarea
                          placeholder="Write A Review"
                          className="border-2 border-slate-500 h-36 p-3 mt-5 w-full rounded-md"
                          id="ta"
                        >
                          {" "}
                        </textarea>
                      </div>

                      <button
                        type="button"
                        className="inline-flex float-right mt-3 rounded-md border border-transparent bg-green-100 px-4 py-2 text-sm font-medium text-green-900 hover:bg-green-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-green-500 focus-visible:ring-offset-2"
                        onClick={() => setIsOpen(false)}
                      >
                        Post Review
                      </button>
                    </Dialog.Panel>
                  </Transition.Child>
                </div>
              </div>
            </Dialog>
          </Transition>
        </section>
      </main>
    </div>
  );
}
