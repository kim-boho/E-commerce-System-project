import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "./components/Header";
import { signup } from "./hooks/userRequests";
interface ErrorMessage {
  name?: string;
  message?: string;
}

const Signup = () => {
  const [errorMessages, setErrorMessages] = useState<ErrorMessage>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const errors = {
    email: "Invalid username",
    pass: "Invalid password",
    password_again: "Must match password entered above",
    fname: "First name required.",
    lname: "Last name required.",
    loginFail: "Invalid username or password. Please try again.",
  };

  const validate = (
    email: string,
    password: string,
    password_again: string,
    fname: string,
    lname: string
  ) => {
    let result = true;
    if (email == null || email == "") {
      setErrorMessages({ name: "email", message: errors.email });
      result = false;
    }
    if (password == null || password == "") {
      setErrorMessages({
        name: "password_again",
        message: errors.password_again,
      });
      result = false;
    }
    if (
      password_again == null ||
      password_again == "" ||
      password !== password_again
    ) {
      setErrorMessages({
        name: "password_again",
        message: errors.password_again,
      });
      result = false;
    }
    if (fname == null || fname == "") {
      setErrorMessages({ name: "fname", message: errors.fname });
      result = false;
    }
    if (lname == null || lname == "") {
      setErrorMessages({ name: "lname", message: errors.lname });
      result = false;
    }
    return result;
  };

  const handleSubmit = async (event: { preventDefault: () => void }) => {
    //Prevent page reload
    event.preventDefault();
    const { email, password, fname, lname, password_again } = document.forms[0];
    const user = {
      email: email.value,
      password: password.value,
      fname: fname.value,
      lname: lname.value,
    };

    if (
      validate(
        user.email,
        user.password,
        password_again.value,
        user.fname,
        user.lname
      )
    ) {
      const response = await signup(user);

      if (response.email && response.errorMessage == null) {
        setIsSubmitted(true);
      } else {
        setErrorMessages({ name: "loginFail", message: response.errorMessage });
      }
    } else {
      setErrorMessages({ name: "loginFail", message: errors.loginFail });
    }
  };

  const renderErrorMessage = (name: string) =>
    name === errorMessages.name && (
      <div className="error">{errorMessages.message}</div>
    );

  const LoginAndBackToHomeLinkButton = (
    <>
      <button
        type="button"
        className="my-4 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
      >
        <Link to="/login">Login</Link>
      </button>
      <button
        type="button"
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
      >
        <Link to="/">Back to home</Link>
      </button>
    </>
  );
  const renderForm = (
    <>
      <div className="min-h-full flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <img
            className="mx-48 h-12 w-auto"
            src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg"
            alt="Workflow"
          />
          <h2 className="mt-6 mx-0 w-full text-center text-3xl font-extrabold text-gray-900">
            Create a new Web Store account
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600"></p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="loginFail break-words text-center text-[#cc0000]">
                {renderErrorMessage("loginFail")}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  First Name
                </label>
                <div className="mt-1">
                  <input
                    name="fname"
                    type="text"
                    autoComplete="current-password"
                    required
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {renderErrorMessage("fname")}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Last Name
                </label>
                <div className="mt-1">
                  <input
                    id="lname"
                    name="lname"
                    type="text"
                    autoComplete="current-password"
                    required
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {renderErrorMessage("lname")}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Email address
                </label>
                <div className="mt-1">
                  <input
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {renderErrorMessage("email")}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="mt-1">
                  <input
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {renderErrorMessage("password")}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Password Again
                </label>
                <div className="mt-1">
                  <input
                    name="password_again"
                    type="password"
                    autoComplete="current-password"
                    required
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {renderErrorMessage("password_again")}
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Sign up
                </button>

                <h2 className="mt-2 ml-44">Or</h2>

                {LoginAndBackToHomeLinkButton}
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );

  const renderSuccess = (
    <>
      <div>Sign up successful. Please log in</div>
      <div>{LoginAndBackToHomeLinkButton}</div>
    </>
  );

  return (
    <div className="signup-form">
      <Header />

      {isSubmitted ? renderSuccess : renderForm}
    </div>
  );
};

export default Signup;
