/**
 * 
 */
package com.groupad.backend.exception;

/**
 * @author Boho Kim
 *
 */
public class BadCredentialsException {

}
