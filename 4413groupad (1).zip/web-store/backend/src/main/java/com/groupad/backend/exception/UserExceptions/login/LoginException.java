package com.groupad.backend.exception.UserExceptions.login;

public class LoginException extends Exception {

    public LoginException() {
        super();
    }

    public LoginException(String arg0) {
        super(arg0);
    }

    public LoginException(Exception e) {
        super(e);
    }

}
