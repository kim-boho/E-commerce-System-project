package com.groupad.backend.enums;

public enum EventType {
    PURCHASE,
    CART,
    VIEW
}
