package com.groupad.backend.exception.UserExceptions.signup;

public class NoNameException extends AccountCreationException {

    public NoNameException(String msg) {
        super(msg);
    }

}
